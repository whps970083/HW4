#include "syscall.h"

main()
        {
                int     n;
                for (n=2020;n<=2030;n++)
                        PrintInt(n);
        }
